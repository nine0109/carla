'''
getting colour' masks

drivable road
rgb 128, 68, 128
hsv 300°, 47%, 50%

lane markings
rgb 157, 234, 50
hsv 85°, 79%, 92%

cars
rgb 0, 0, 142
hsv 240°, 100%, 56%

people
rgb 220, 20, 60
hsv 348°, 91%, 86%
'''